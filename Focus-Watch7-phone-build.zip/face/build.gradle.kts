plugins { id("com.android.application") }
android { namespace = "com.example.meetingface.face"; compileSdk = 35
    defaultConfig { applicationId = "com.example.meetingface.face"; minSdk = 33; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
