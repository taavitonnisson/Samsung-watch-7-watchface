package com.example.meetingface

import android.Manifest
import android.content.pm.PackageManager
import android.provider.CalendarContract
import android.text.format.DateFormat
import androidx.wear.watchface.complications.data.*
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService

class MeetingComplication : SuspendingComplicationDataSourceService() {
 override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
  if (request.complicationType != ComplicationType.LONG_TEXT) return null
  val (headline, location) = nextMeeting()
  val description = PlainComplicationText.Builder("$headline. $location").build()
  return LongTextComplicationData.Builder(
   text = PlainComplicationText.Builder(headline).build(),
   contentDescription = description
  ).setTitle(PlainComplicationText.Builder(location).build()).build()
 }
 override fun getPreviewData(type: ComplicationType): ComplicationData? {
  if (type != ComplicationType.LONG_TEXT) return null
  return LongTextComplicationData.Builder(
   PlainComplicationText.Builder("11:00 Weekly team meeting").build(),
   PlainComplicationText.Builder("Next meeting, Room 3").build()
  ).setTitle(PlainComplicationText.Builder("Room 3").build()).build()
 }
 private fun nextMeeting(): Pair<String,String> {
  if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) return "Open Meeting Calendar" to "Grant calendar access"
  val now = System.currentTimeMillis()
  val end = now + 7L*24*60*60*1000
  val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { CalendarContract.Instances.appendId(it, now); CalendarContract.Instances.appendId(it, end) }.build()
  val columns = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.CALENDAR_VISIBLE)
  return try {
   contentResolver.query(uri, columns, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { cursor ->
    val titleCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
    val beginCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
    val endCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.END)
    val locCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_LOCATION)
    val allDayCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)
    val visibleCol = cursor.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_VISIBLE)
    while(cursor.moveToNext()) {
     if(cursor.getInt(allDayCol)!=0 || cursor.getInt(visibleCol)==0 || cursor.getLong(endCol)<=now) continue
     val start=cursor.getLong(beginCol)
     val time=DateFormat.format("HH:mm", start).toString()
     val title=cursor.getString(titleCol).orEmpty().ifBlank { "Untitled meeting" }
     val location=cursor.getString(locCol).orEmpty().ifBlank { "No room specified" }
     return "$time $title" to location
    }
   }
   "No upcoming meetings" to "Next 7 days"
  } catch(e: Exception) { "Calendar unavailable" to "Check calendar sync" }
 }
}
