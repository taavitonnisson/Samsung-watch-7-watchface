package com.example.meetingface

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.TextView

class PermissionActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val view = TextView(this).apply { text = "Meeting Calendar\n\nAllow calendar access when prompted. Then edit Meeting Face and choose 'Next meeting and room' for the large complication."; textSize = 20f; setPadding(32,48,32,32) }
  setContentView(view)
  if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 7)
 }
}
