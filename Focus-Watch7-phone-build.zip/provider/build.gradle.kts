plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.meetingface"; compileSdk = 35
 defaultConfig { applicationId = "com.example.meetingface.provider"; minSdk = 33; targetSdk = 35; versionCode = 1; versionName = "0.1" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.wear.watchface:watchface-complications-data-source-ktx:1.2.1") }
